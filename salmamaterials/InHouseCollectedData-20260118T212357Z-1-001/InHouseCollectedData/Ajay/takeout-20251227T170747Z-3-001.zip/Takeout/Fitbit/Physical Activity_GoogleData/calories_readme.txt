Time Series Data Export

The Time Series export provides a detailed timeline of your tracked activity.

Files Included:
----------

calories_YYYY-MM-DD.csv               - Where YYYY-MM-DD is the starting date for the entries in the file.

Each entry has the following values:

    timestamp                         - Date and time at which the entry was logged.
    calories                          - Number of calories burned.
    data source                       - The origin or source of this data.
